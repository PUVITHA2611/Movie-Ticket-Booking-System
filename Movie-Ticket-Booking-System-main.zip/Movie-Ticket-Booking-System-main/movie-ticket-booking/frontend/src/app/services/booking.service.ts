import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class BookingService {
  private apiUrl = 'http://localhost:3000/api/bookings'; // Use the `/api/bookings` endpoint

  constructor(private http: HttpClient) {}

  // Get all bookings
  getAllBookings(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}`);
  }

  // Get booking details by ID
  getBookingDetails(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/${id}`);
  }

  // Create a new booking
  createBooking(data: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}`, data);
  }
}