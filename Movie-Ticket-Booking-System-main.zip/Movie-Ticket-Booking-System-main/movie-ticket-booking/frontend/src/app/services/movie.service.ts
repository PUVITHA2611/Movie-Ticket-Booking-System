import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class MovieService {
  private apiUrl = 'http://localhost:3000/api'; // Replace with your backend API base URL

  constructor(private http: HttpClient) {}

  // Fetch all movies
  getMovies(): Observable<any[]> {
    return this.http.get<any[]>(`${this.apiUrl}/movies`);
  }

  // Fetch movie details by ID
  getMovieDetails(id: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/movies/${id}`);
  }

  // Fetch booking details by ID
  getBookingDetails(bookingId: number): Observable<any> {
    return this.http.get<any>(`${this.apiUrl}/bookings/${bookingId}`);
  }

  // Create a new booking
  createBooking(booking: any): Observable<any> {
    return this.http.post<any>(`${this.apiUrl}/bookings`, booking);
  }
}