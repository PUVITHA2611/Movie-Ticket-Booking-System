import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { CommonModule } from '@angular/common';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MovieListComponent } from './components/movie-list/movie-list.component';
import { MovieDetailsComponent } from './components/movie-details/movie-details.component';
import { BookingConfirmationComponent } from './components/booking-confirmation/booking-confirmation.component';
import { MatGridListModule } from '@angular/material/grid-list'; // Import MatGridListModule
import { MatToolbarModule } from '@angular/material/toolbar'; // For mat-toolbar
import { MatIconModule } from '@angular/material/icon'; // For mat-icon
import { SeatService } from './services/seat.service';
import { SeatSelectionComponent } from './components/seat-selection/seat-selection.component';
import { ToastrModule } from 'ngx-toastr';



@NgModule({
  declarations: [
    AppComponent,
    SeatSelectionComponent,
    MovieListComponent,
    MovieDetailsComponent,
    BookingConfirmationComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    CommonModule,
    BrowserAnimationsModule,
    MatGridListModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatSelectModule,
    MatProgressSpinnerModule,
    AppRoutingModule,
    MatToolbarModule,
    MatIconModule,
    ToastrModule.forRoot({ // Add ToastrModule with configuration
      timeOut: 3000, // Duration in milliseconds (3 seconds)
      positionClass: 'toast-top-center', // Position of the toast
      preventDuplicates: true, // Prevent duplicate notifications
    }),

  ],
  bootstrap: [AppComponent],
  providers:[SeatService]
})
export class AppModule {}