import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { SeatService } from 'src/app/services/seat.service';
import { Seat } from 'src/app/models/seat.model';
import { MovieService } from 'src/app/services/movie.service';


@Component({
  selector: 'app-seat-selection',
  templateUrl: './seat-selection.component.html',
  styleUrls: ['./seat-selection.component.scss'],
})
export class SeatSelectionComponent implements OnInit {
  movie : any={};
  seats: Seat[] = [];
  rows: Seat[][] = []; // Add this property to store rows
  selectedSeats: Seat[] = [];
  totalPrice: number = 0;
  errorMessage: string = '';
  successMessage: string = '';

  constructor(
    private route: ActivatedRoute,
    private seatService: SeatService,
    private movieService: MovieService,
    private router: Router
  ) {}

  ngOnInit() {
    const movieId = this.getMovieIdFromRoute();
    if (movieId === null) return;

    this.fetchSeats(movieId);

    this.movieService.getMovieDetails(movieId).subscribe(
      (data) => {
      const movieId = +this.route.snapshot.params['id'];
        this.movie = data;
      },
      (error) => {
        console.error('Error fetching movie details:', error);
      }
    );
  }

  private getMovieIdFromRoute(): number | null {
    const movieId = parseInt(this.route.snapshot.params['id'], 10);
    if (isNaN(movieId)) {
      this.errorMessage = 'Invalid movie ID';
      return null;
    }
    return movieId;
  }

  fetchSeats(movieId: number) {
    this.seatService.getSeatsByMovieId(movieId).subscribe(
      (data: Seat[]) => {
        this.seats = data.map((seat) => ({
          ...seat,
          selected: false,
          price: seat.price || 0,
        }));

        // Divide seats into rows (10 seats per row)
        const seatsPerRow = 10;
        this.rows = this.seats.reduce((rows: Seat[][], seat, index) => {
          const rowIndex = Math.floor(index / seatsPerRow);
          if (!rows[rowIndex]) {
            rows[rowIndex] = [];
          }
          rows[rowIndex].push(seat);
          return rows;
        }, []);
      },
      (error) => {
        this.errorMessage = 'Failed to load seat data. Please try again later.';
      }
    );
  }

  selectSeat(seat: Seat) {
    if (!seat.booked) {
      seat.selected = !seat.selected;
      this.selectedSeats = this.seats.filter((s) => s.selected);
      this.totalPrice = this.selectedSeats.reduce((sum, s) => sum + Number(s.price || 0), 0);
    }
  }

  confirmBooking() {
    if (this.selectedSeats.length === 0) {
      this.errorMessage = 'Please select at least one seat to proceed.';
      return;
    }

    const booking = {
      movieId: parseInt(this.route.snapshot.params['id'], 10), // Ensure this is a number
      selectedSeats: this.selectedSeats.map((s) => s.seat_number), // Ensure this is an array of strings
      totalPrice: this.totalPrice, // Ensure this is greater than 0
    };

    this.seatService.createBooking(booking).subscribe(
      (data: any) => {
        this.successMessage = 'Booking successful! Redirecting...';
        setTimeout(() => {
          console.log('Booking data to pass:', { ...booking, id: data.id });
          this.router.navigate(['/booking', data.id]);
        }, 2000);
      },
      (error) => {
        this.errorMessage = 'Failed to complete the booking. Please try again.';
      }
    );
  }
}