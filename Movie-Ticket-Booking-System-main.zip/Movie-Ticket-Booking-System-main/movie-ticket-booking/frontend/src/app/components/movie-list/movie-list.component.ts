import { Component, OnInit, ElementRef, ViewChild, HostListener } from '@angular/core';
import { Router } from '@angular/router';
import { MovieService } from 'src/app/services/movie.service';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { Subject } from 'rxjs';

@Component({
  selector: 'app-movie-list',
  templateUrl: './movie-list.component.html',
  styleUrls: ['./movie-list.component.scss'],
})
export class MovieListComponent implements OnInit {
  movies: any[] = [];
  error: string | null = null;
  isLoading: boolean = true;

  // Search-related properties
  @ViewChild('searchInput') searchInput!: ElementRef;
  searchQuery: string = '';
  filteredMovies: any[] = [];
  isSearching: boolean = false; // Loading state for search suggestions
  private searchSubject = new Subject<string>();

  constructor(private movieService: MovieService, private router: Router) {}

  ngOnInit() {
    // Fetch all movies when the component initializes
    this.movieService.getMovies().subscribe(
      (data: any[]) => {
        this.movies = data;
        this.isLoading = false;
      },
      (error) => {
        console.error('Error fetching movies:', error);
        this.error = 'Failed to load movies. Please try again later.';
        this.isLoading = false;
      }
    );

    // Subscribe to search input changes
    this.searchSubject
      .pipe(
        debounceTime(300), // Wait for 300ms after the last input
        distinctUntilChanged(), // Ignore consecutive duplicate inputs
        switchMap((query) => {
          if (query.trim() === '') {
            this.filteredMovies = [];
            return [];
          }
          this.isSearching = true;
          return this.movieService.getMovies().pipe(
            // Filter movies locally for simplicity
            switchMap(() => {
              this.filteredMovies = this.movies.filter((movie) =>
                movie.title.toLowerCase().includes(query.trim().toLowerCase())
              );
              this.isSearching = false;
              return [];
            })
          );
        })
      )
      .subscribe(
        () => {},
        (error) => {
          console.error('Error fetching search suggestions:', error);
          this.isSearching = false;
        }
      );
  }

  onSearchChange(query: string) {
    this.searchQuery = query;
    this.searchSubject.next(query); // Emit the search query for suggestions
  }

  selectMovie(movie: any) {
    this.router.navigate(['/movies', movie.id]); // Navigate to movie details
    this.clearSearch(); // Clear the search bar and suggestions
  }

  clearSearch() {
    this.searchQuery = '';
    this.filteredMovies = [];
  }

  @HostListener('document:click', ['$event'])
  onClickOutside(event: MouseEvent) {
    if (!this.searchInput.nativeElement.contains(event.target as Node)) {
      this.clearSearch(); // Clear search when clicking outside the dropdown
    }
  }

  goToMovieDetails(movieId: number) {
    this.router.navigate(['/movies', movieId]);
  }
}