import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { MovieService } from 'src/app/services/movie.service';
import { BookingService } from 'src/app/services/booking.service';


@Component({
  selector: 'app-booking-confirmation',
  templateUrl: './booking-confirmation.component.html',
  styleUrls: ['./booking-confirmation.component.scss'],
})
export class BookingConfirmationComponent implements OnInit {
  booking: any;
  movie:any={};
  successMessage:string|null=null;
  showtime : string = 'Showtime not availabe';

  constructor(
    private route: ActivatedRoute,
    private movieService: MovieService,
    private bookingService: BookingService,
  ) {}

  ngOnInit() { 
    const bookingId = this.route.snapshot.params['id'];
    this.bookingService.getBookingDetails(bookingId).subscribe(
      (data: any) => {
        this.movie=data
        // Map API response to booking fields
        this.booking = {
          id: data.id,
          movie_id: data.movie_id,
          movieTitle: '', // Will be fetched later if missing
          selectedSeats: data.selected_seats || ['No seats selected'],
          totalPrice: data.total_price || 'N/A',
          
        };

        // Fetch movie title if not present in booking data
        if (!this.booking.movieTitle && this.booking.movie_id) {
          this.movieService.getMovieDetails(this.booking.movie_id).subscribe(
            (movie: any) => {
              this.booking.movieTitle = movie.title;
              this.showtime=movie.showtime;
               // Show success message
              this.successMessage = 'Tickets booked successfully!';

        // Automatically hide the message after 5 seconds
              setTimeout(() => {
              this.successMessage = null;
              }, 5000); // 5000ms = 5 seconds

            },
            (error: any) => {
              console.error('Error fetching movie details:', error);
            }
          );
        }
      },
      (error: any) => {
        console.error('Error fetching booking details:', error);
      }
    );
  }
}