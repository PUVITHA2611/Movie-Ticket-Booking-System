export interface Booking {
  id: number;
  movie_id: number;
  movieTitle?: string;
  selected_seats: string[]; // e.g., ["A1", "A2"]
  total_price: number;
  booking_time?: string;
  showtime?: string; // Add this field
}