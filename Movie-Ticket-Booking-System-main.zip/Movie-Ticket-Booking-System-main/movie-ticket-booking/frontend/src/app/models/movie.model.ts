export interface Movie {
  id: number;
  title: string;
  genre: string;
  duration: number;
  rating: number;
  showtime: string;
  created_at?: string;
  poster?: string;
}