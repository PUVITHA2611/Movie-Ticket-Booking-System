export interface Seat {
  seat_number: string; // The seat number (e.g., "A1", "B2")
  status: string; // The status of the seat (e.g., "available", "booked")
  booked: boolean; // Whether the seat is booked or not (true/false)
  price: number; // The price of the seat
  selected?: boolean; // Whether the seat is selected (used in the UI)
}