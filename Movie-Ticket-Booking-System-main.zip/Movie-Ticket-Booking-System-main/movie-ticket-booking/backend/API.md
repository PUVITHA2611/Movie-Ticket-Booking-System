# Movie Ticket Booking API

## Movie API
### GET /api/movies
- **Description**: Fetch all movies.
- **Response**:
  ```json
  [
      {
          "id": 1,
          "title": "Movie 1",
          "genre": "Drama",
          "duration": 120,
          "rating": 7.5,
          "poster": "http://localhost:3000/images/img1.jpeg",
          "showtime": "2025-04-16T18:00:00.000Z",
          "created_at": "2025-04-15T12:00:00.000Z"
      }
  ]