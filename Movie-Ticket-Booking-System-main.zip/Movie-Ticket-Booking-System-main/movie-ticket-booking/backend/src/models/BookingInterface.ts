export interface Booking {
  id: number;
  movie_id: number;
  selected_seats: string; // JSON stored as string
  total_price: number;
  booking_time: Date;
  showtime:Date
}