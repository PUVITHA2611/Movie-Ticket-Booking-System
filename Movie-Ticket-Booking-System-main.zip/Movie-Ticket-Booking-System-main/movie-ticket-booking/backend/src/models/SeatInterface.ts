export interface Seat {
    seat_number: string; // The seat number (e.g., "A1", "B2")
    status: string; // The status of the seat (e.g., "available", "booked")
  }