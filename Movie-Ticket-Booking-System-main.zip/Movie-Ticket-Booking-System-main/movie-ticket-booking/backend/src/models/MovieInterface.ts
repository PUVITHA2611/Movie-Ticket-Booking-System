export interface Movie {
  id: number;
  title: string;
  genre: string;
  duration: number;
  rating: number;
  poster: string;
  showtime:Date;
  created_at: Date;
}