
export const environment = {
  port: process.env.PORT || 3000,
  dbHost: process.env.DB_HOST || 'localhost',
  dbUser: process.env.DB_USER || 'root',
  dbPassword: process.env.DB_PASSWORD || 'Ooha2004@',
  dbName: process.env.DB_NAME || 'movie_booking',
};