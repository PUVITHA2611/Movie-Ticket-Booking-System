import { db } from '../config/database';
import { RowDataPacket } from 'mysql2/promise';

export const getSeatsByMovieId = async (
  movieId: number
): Promise<{ seat_number: string; status: string; price: number; booked: boolean }[]> => {
  const [rows]: [RowDataPacket[], any] = await db.query(
    'SELECT seat_number, status, price, is_booked AS booked FROM seats WHERE movie_id = ?',
    [movieId]
  );

  if (!rows || rows.length === 0) {
    throw new Error('No seats found for the given movie ID'); // Add error handling for empty results
  }

  return rows as { seat_number: string; status: string; price: number; booked: boolean }[];
};