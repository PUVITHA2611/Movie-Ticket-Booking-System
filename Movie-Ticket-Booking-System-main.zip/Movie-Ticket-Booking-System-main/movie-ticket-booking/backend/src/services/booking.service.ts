import { RowDataPacket, ResultSetHeader } from 'mysql2/promise'; // Import necessary types from mysql2
import { db } from '../config/database';
import { Booking } from '../models/BookingInterface';

/**
 * Create a new booking in the database.
 * @param {number} movie_id - ID of the movie being booked.
 * @param {string} selected_seats - JSON string representing selected seats.
 * @param {number} total_price - Total price for the booking.
 * @returns {Promise<Booking>} The created booking object.
 */
export const createBooking = async (
  movie_id: number,
  selected_seats: string[],
  total_price: number,
  showtime:Date
): Promise<Booking> => {
  const connection = await db.getConnection();
  await connection.beginTransaction();

  try {
    const selectedSeatsJson = JSON.stringify(selected_seats);

    const [result]: [ResultSetHeader, any] = await db.query(
      'INSERT INTO bookings (movie_id, selected_seats, total_price, booking_time,showtime) VALUES (?, ?, ?, NOW(),?)',
      [movie_id, selectedSeatsJson, total_price,showtime]
    );

    const bookingId = result.insertId;

    // 2. Update the status of selected seats to 'unavailable' in the seats table
    const seatPlaceholders = selected_seats.map(() => '?').join(', ');
    const seatUpdateQuery = `UPDATE seats SET status = 'booked', is_booked = 1, booked_at = NOW() WHERE movie_id = ? AND seat_number IN (${seatPlaceholders})`;

    await connection.query(seatUpdateQuery, [movie_id, ...selected_seats]);

    // 3. Commit the transaction
    await connection.commit();


    // Return the created booking details
    return {
      id: result.insertId,
      movie_id,
      selected_seats:selectedSeatsJson,
      total_price,
      booking_time: new Date(),
      showtime
      
    };
  } catch (error) {
    // Rollback the transaction in case of any errors
    await connection.rollback();
    console.error('Error creating booking:', error);
    throw new Error('Failed to create booking');
  } finally {
    connection.release(); // Release the connection
  }
};

/**
 * Get a booking by its ID.
 * @param {number} id - The ID of the booking to retrieve.
 * @returns {Promise<Booking | null>} The booking object or null if not found.
 */
export const getBookingById = async (id: number): Promise<Booking | null> => {
  try {
    const [rows]: [Booking[] & RowDataPacket[], any] = await db.query(
      'SELECT * FROM bookings WHERE id = ?',
      [id]
    );

    // Return the first booking if it exists, otherwise null
    return rows.length > 0 ? rows[0] : null;
  } catch (error) {
    console.error(`Error fetching booking with ID ${id}:`, error);
    throw new Error(`Failed to fetch booking with ID ${id}`);
  }
};

export const getAllBookings= async (): Promise<Booking[]> => {
  try {
    const [rows]: [Booking[] & RowDataPacket[], any] = await db.query('SELECT * FROM bookings');
    return rows;
  } catch (error) {
    console.error('Error fetching all bookings:', error);
    throw new Error('Failed to fetch bookings');
  }
};