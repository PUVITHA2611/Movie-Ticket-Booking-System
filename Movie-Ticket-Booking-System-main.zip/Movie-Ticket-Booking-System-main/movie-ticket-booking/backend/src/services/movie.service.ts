import { RowDataPacket } from 'mysql2/promise'; // Needed for type compatibility
import { db } from '../config/database';
import { Movie } from '../models/MovieInterface';

/**
 * Fetch all movies from the database.
 * @returns {Promise<Movie[]>} Array of movies.
 */
export const getAllMovies = async (): Promise<Movie[]> => {
  try {
    const [rows]: [Movie[] & RowDataPacket[], any] = await db.query(
      'SELECT * FROM movies'
    );
    return rows; // Rows will be typed as an array of Movie objects
  } catch (error) {
    console.error('Error fetching movies:', error);
    throw new Error('Failed to fetch movies');
  }
};

/**
 * Fetch a movie by its ID.
 * @param {number} id - The ID of the movie to fetch.
 * @returns {Promise<Movie | null>} The movie object or null if not found.
 */


export const getMovieById = async (id: number): Promise<Movie | null> => {
    try {
        // Query the database and fetch rows
        const [rows] = await db.query<RowDataPacket[]>('SELECT * FROM movies WHERE id = ?', [id]);
      
        if (rows.length > 0) {
          const movie = rows[0] as Movie; // Cast to Movie type
          return movie;
        }
      
        return null; // No movie found
      } catch (error) {
        console.error(`Error fetching movie with ID ${id}:`, error);
        throw new Error(`Failed to fetch movie with ID ${id}`);
      }
};