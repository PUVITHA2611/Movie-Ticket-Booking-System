import express from 'express';
import cors from 'cors';
import movieRoutes from './routes/movieRoutes';
import bookingRoutes from './routes/bookingRoutes';
import seatRoutes from './routes/seatRoutes';

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// Default Router
app.get('/', (req, res) => {
  console.log('Root route / was hit'); // Debugging log
  res.send('Welcome to the Movie Ticket Booking API');
});

// Organized API Routes
app.use('/api/movies', movieRoutes); // Movie-related routes
app.use('/api/seats', seatRoutes);   // Seat-related routes
app.use('/api/bookings', bookingRoutes); // Booking-related routes

export default app;