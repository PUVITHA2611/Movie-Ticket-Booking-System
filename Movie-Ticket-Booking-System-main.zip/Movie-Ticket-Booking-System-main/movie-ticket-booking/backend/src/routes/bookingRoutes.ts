import express from 'express';
import { createNewBooking, getBookingDetails, getAllBookings } from '../controllers/bookingController';

const router = express.Router();

// Create a new booking
router.post('/', createNewBooking);

// Get booking details by ID
router.get('/:id', getBookingDetails);

// Get all bookings
router.get('/', getAllBookings);

export default router;