import express from 'express';
import { getSeatAvailability } from '../controllers/seatController';

const router = express.Router();

// Seat availability endpoint
router.get('/:id', getSeatAvailability);

export default router;