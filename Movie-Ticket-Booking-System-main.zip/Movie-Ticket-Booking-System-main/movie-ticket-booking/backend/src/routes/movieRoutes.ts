import { Router } from 'express';
import { getMovies, getMovieDetails } from '../controllers/movieController';

const router = Router();

// Route to fetch all movies
router.get('/', getMovies);

// Route to fetch a movie by its ID
router.get('/:id', getMovieDetails);

export default router;