import { Request, Response } from 'express';
import { getAllMovies, getMovieById } from '../services/movie.service';

/**
 * Fetch all movies.
 */
export const getMovies = async (req: Request, res: Response): Promise<void> => {
  try {
    console.log(`Received request for movie`);
    const movies = await getAllMovies();
    res.status(200).json(movies);
  } catch (error) {
    console.error('Error fetching movies:', error); // Added logging for debugging
    res.status(500).json({ error: 'Failed to fetch movies' });
  }
};

/**
 * Fetch movie details by ID.
 */
export const getMovieDetails = async (req: Request, res: Response): Promise<void> => {
  try {
    const movieId = parseInt(req.params.id, 10);
    console.log(`Received request for movie ID: ${req.params.id}`);
    // Validate movie ID
    if (isNaN(movieId)) {
      res.status(400).json({ error: 'Invalid movie ID' });
      return;
    }

    const movie = await getMovieById(movieId);

    // Handle case where movie is not found
    if (!movie) {
      res.status(404).json({ error: 'Movie not found' });
      return;
    }

    res.status(200).json(movie);
  } catch (error) {
    console.error('Error fetching movie details:', error); // Added logging for debugging
    res.status(500).json({ error: 'Failed to fetch movie details' });
  }
};