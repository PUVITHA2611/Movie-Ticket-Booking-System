import { Request, Response } from 'express';
import { createBooking, getBookingById } from '../services/booking.service';
import { getAllBookings as getAllBookingsService } from '../services/booking.service';
/**
 * Create a new booking.
 */
export const createNewBooking = async (req: Request, res: Response): Promise<void> => {
  try {
    const { movie_id, selected_seats, total_price , showtime } = req.body;

    if (!movie_id || !selected_seats || total_price <= 0 ) {
      res.status(400).json({ error: 'Invalid booking details' });
      return;
    }

    const booking = await createBooking(movie_id, selected_seats, total_price, showtime);
    res.status(201).json(booking);
  } catch (error) {
    console.error('Error creating booking:', error);
    res.status(500).json({ error: 'Failed to create booking' });
  }
};

/**
 * Get details of a booking by ID.
 */
export const getBookingDetails = async (req: Request, res: Response): Promise<void> => {
  try {
    const bookingId = parseInt(req.params.id, 10);

    if (isNaN(bookingId)) {
      res.status(400).json({ error: 'Invalid booking ID' });
      return;
    }

    const booking = await getBookingById(bookingId);
    if (!booking) {
      res.status(404).json({ error: 'Booking not found' });
      return;
    }

    res.status(200).json(booking);
  } catch (error) {
    console.error('Error fetching booking details:', error);
    res.status(500).json({ error: 'Failed to fetch booking details' });
  }
};

export const getAllBookings = async (req: Request, res: Response): Promise<void> => {
  try {
    const bookings = await getAllBookingsService(); // Call the service function to fetch all bookings
    res.status(200).json(bookings); // Return the bookings in the response
  } catch (error) {
    console.error('Error fetching all bookings:', error);
    res.status(500).json({ error: 'Failed to fetch bookings' });
  }
};